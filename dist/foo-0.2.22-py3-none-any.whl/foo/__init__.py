print(__file__)
